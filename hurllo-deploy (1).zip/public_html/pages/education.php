<?php
$topic = preg_replace('/[^a-z0-9\-]/', '', $_GET['topic'] ?? '');

$topics = [
    'how-car-hire-works' => [
        'title' => 'How Car Hire Works in South Africa',
        'icon' => '🚗',
        'content' => [
            'intro' => 'Renting a car in South Africa involves several key steps and financial commitments that every traveller should understand before signing any agreement.',
            'sections' => [
                [
                    'heading' => 'The Booking Process',
                    'body' => 'Car hire in South Africa can be booked directly through company websites, at airport counters, or via third-party platforms. Always compare prices across multiple channels as rates can vary significantly. Direct bookings often offer more flexibility for modifications and cancellations.'
                ],
                [
                    'heading' => 'What You Need to Rent',
                    'body' => 'To rent a car in South Africa you typically need: a valid driver\'s licence (international licence recommended for foreign visitors), a credit card for the deposit (some companies accept debit cards), your passport or ID, and proof of accommodation or travel itinerary.'
                ],
                [
                    'heading' => 'Understanding the Rental Agreement',
                    'body' => 'The rental agreement is a legally binding contract. Key items to check include: the daily rate, mileage policy (unlimited vs per-km), fuel policy (full-to-full is standard), insurance inclusions, excess amount, and any additional driver fees.'
                ],
                [
                    'heading' => 'Collecting and Returning the Vehicle',
                    'body' => 'Always inspect the vehicle thoroughly before driving away and document any existing damage with photos. Return the vehicle with a full tank (unless pre-paid fuel option was selected) and at the agreed time to avoid additional charges.'
                ]
            ]
        ]
    ],
    'financial-exposure' => [
        'title' => 'Understanding Financial Exposure in Car Hire',
        'icon' => '💰',
        'content' => [
            'intro' => 'Financial exposure is the total amount of money you could potentially lose or have held during a car hire. Understanding this is critical to making an informed decision.',
            'sections' => [
                [
                    'heading' => 'What is a Security Deposit?',
                    'body' => 'A security deposit is a refundable amount held on your credit card at the start of the rental. In South Africa, deposits typically range from R1,500 to R5,000 depending on the company and vehicle class. This money is not charged — it is blocked on your card and released after the vehicle is returned undamaged.'
                ],
                [
                    'heading' => 'What is an Excess?',
                    'body' => 'The excess (also called a deductible) is the maximum amount you would pay in the event of an accident or damage to the vehicle. South African excesses typically range from R10,000 to R30,000. This is separate from the deposit and represents your maximum liability.'
                ],
                [
                    'heading' => 'Calculating Your Total Exposure',
                    'body' => 'Your total financial exposure = Deposit + Excess. For example, if a company charges a R3,000 deposit and has a R20,000 excess, your maximum exposure is R23,000. Use our Risk Simulator on the homepage to calculate your specific exposure.'
                ],
                [
                    'heading' => 'How to Reduce Financial Exposure',
                    'body' => 'Options to reduce exposure include: purchasing Collision Damage Waiver (CDW) insurance, choosing companies with lower deposits and excesses, using a credit card with built-in rental car insurance, or purchasing standalone travel insurance that covers rental car excess.'
                ]
            ]
        ]
    ],
    'refund-guide' => [
        'title' => 'Car Hire Deposit Refund Guide South Africa',
        'icon' => '⏱️',
        'content' => [
            'intro' => 'Getting your deposit back after a car hire can be frustrating if you don\'t know what to expect. Here\'s everything you need to know about deposit refunds in South Africa.',
            'sections' => [
                [
                    'heading' => 'How Long Does a Refund Take?',
                    'body' => 'Deposit refund times in South Africa vary significantly by company. The best companies refund within 2-4 business days. Average companies take 5-7 business days. Some companies can take up to 14 business days. Always check the refund policy before booking.'
                ],
                [
                    'heading' => 'Why Refunds Are Delayed',
                    'body' => 'Common reasons for delayed refunds include: vehicle inspection taking time, toll fee reconciliation, fuel charge processing, damage assessment, and administrative processing. Some companies batch process refunds weekly.'
                ],
                [
                    'heading' => 'How to Speed Up Your Refund',
                    'body' => 'To get your deposit back faster: return the vehicle on time, ensure the tank is full, document the return with photos, get a written confirmation of return, and follow up with the company if the refund hasn\'t arrived within their stated timeframe.'
                ],
                [
                    'heading' => 'What to Do If Your Refund Is Late',
                    'body' => 'If your deposit hasn\'t been refunded within the stated timeframe: contact the company\'s customer service, escalate to a manager if needed, contact your bank to dispute the hold, and as a last resort, contact the Consumer Protection Act authorities.'
                ]
            ]
        ]
    ],
    'cross-border' => [
        'title' => 'Cross-Border Car Hire Guide South Africa',
        'icon' => '🌍',
        'content' => [
            'intro' => 'Taking a rental car across South Africa\'s borders requires specific permissions and documentation. Not all companies allow cross-border travel, and those that do have specific requirements.',
            'sections' => [
                [
                    'heading' => 'Which Countries Can You Drive To?',
                    'body' => 'The most commonly permitted cross-border destinations from South Africa include: Namibia, Botswana, Lesotho, Swaziland (Eswatini), Zimbabwe, and Mozambique. Each company has different permitted countries, so always confirm before booking.'
                ],
                [
                    'heading' => 'Required Documentation',
                    'body' => 'For cross-border travel you typically need: a cross-border letter from the rental company (usually costs R500-R1,500), your passport, the vehicle\'s registration papers, proof of insurance valid in the destination country, and sometimes a carnet de passage for certain countries.'
                ],
                [
                    'heading' => 'Additional Costs',
                    'body' => 'Cross-border travel usually incurs additional fees including: cross-border permit fee (R500-R1,500), additional insurance premium, and sometimes a higher excess for cross-border travel. Always get a full cost breakdown before agreeing.'
                ],
                [
                    'heading' => 'Important Restrictions',
                    'body' => 'Be aware that: some companies prohibit cross-border travel entirely, some vehicles (especially luxury or premium) may not be permitted cross-border, and driving on unpaved roads may void your insurance in some countries.'
                ]
            ]
        ]
    ],
    'ev-guide' => [
        'title' => 'Electric Vehicle Car Hire Guide South Africa',
        'icon' => '⚡',
        'content' => [
            'intro' => 'Electric vehicle (EV) rentals are emerging in South Africa, but the market is still developing. Here\'s what you need to know before renting an EV in South Africa.',
            'sections' => [
                [
                    'heading' => 'EV Availability in South Africa',
                    'body' => 'EV rental availability in South Africa is currently limited, primarily available in major cities like Johannesburg and Cape Town. The most common EV rental options include the BMW i3, Nissan Leaf, and some Tesla models at premium rental companies.'
                ],
                [
                    'heading' => 'Charging Infrastructure',
                    'body' => 'South Africa\'s EV charging infrastructure is growing but still limited compared to Europe. Major cities have public charging stations, but rural areas and game reserves may have very limited or no charging options. Always plan your route carefully.'
                ],
                [
                    'heading' => 'Range Considerations',
                    'body' => 'South Africa\'s vast distances make range a critical consideration. Most EVs available for rental have a range of 200-400km per charge. For long-distance travel or game drives, a traditional petrol or diesel vehicle may be more practical.'
                ],
                [
                    'heading' => 'EV Rental Costs',
                    'body' => 'EV rentals in South Africa typically cost 20-40% more than equivalent petrol vehicles. However, electricity costs are significantly lower than petrol, so total trip costs may be comparable for shorter distances.'
                ]
            ]
        ]
    ],
    'seasonal-demand' => [
        'title' => 'Seasonal Demand Guide for Car Hire South Africa',
        'icon' => '📅',
        'content' => [
            'intro' => 'Car hire prices and availability in South Africa fluctuate significantly throughout the year. Understanding seasonal demand can help you save money and secure the vehicle you want.',
            'sections' => [
                [
                    'heading' => 'Peak Season (December - January)',
                    'body' => 'December and January are the busiest months for car hire in South Africa. School holidays, Christmas, and New Year drive extremely high demand. Prices can be 30-50% higher than off-peak. Book at least 4-6 weeks in advance for popular vehicle classes.'
                ],
                [
                    'heading' => 'High Season (July School Holidays)',
                    'body' => 'The July school holidays create a secondary peak in demand. SUVs and 7-seaters are particularly in demand for family travel. Book 3-4 weeks in advance to secure your preferred vehicle.'
                ],
                [
                    'heading' => 'Shoulder Season (March-May, September-November)',
                    'body' => 'These months offer a good balance of reasonable prices and good weather. September-October is particularly good for the Garden Route and Namaqualand wildflowers. Prices are typically 10-20% lower than peak season.'
                ],
                [
                    'heading' => 'Low Season (May-June)',
                    'body' => 'May and June offer the best deals on car hire in South Africa. Prices can be 20-30% lower than peak season. However, some coastal areas experience cold and wet weather. Kruger Park is excellent in winter as animals gather at water sources.'
                ]
            ]
        ]
    ]
];

$currentTopic = $topics[$topic] ?? null;

// Breadcrumbs
$crumbs = [
    ['label' => 'Home', 'url' => '/'],
    ['label' => 'Car Hire Guide', 'url' => url('education')]
];
if ($currentTopic) {
    $crumbs[] = ['label' => $currentTopic['title']];
}
echo breadcrumbs($crumbs);

// FAQ Schema
if ($currentTopic):
?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
        <?php foreach ($currentTopic['content']['sections'] as $i => $section): ?>
        {
            "@type": "Question",
            "name": "<?= htmlspecialchars($section['heading']) ?>",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "<?= htmlspecialchars($section['body']) ?>"
            }
        }<?= $i < count($currentTopic['content']['sections']) - 1 ? ',' : '' ?>
        <?php endforeach; ?>
    ]
}
</script>
<?php endif; ?>

<section class="page-hero page-hero--education">
    <div class="container">
        <h1 class="page-title"><?= $currentTopic ? htmlspecialchars($currentTopic['title']) : 'Car Hire Guide South Africa' ?></h1>
        <p class="page-subtitle">Expert intelligence on South African car hire — deposits, excess, cross-border, and more.</p>
    </div>
</section>

<section class="section education-section">
    <div class="container">
        <div class="education-layout">
            
            <!-- Sidebar -->
            <aside class="education-sidebar">
                <div class="topic-nav">
                    <h3>Guide Topics</h3>
                    <ul>
                        <?php foreach ($topics as $topicKey => $topicData): ?>
                        <li>
                            <a href="<?= url('education', '', ['topic' => $topicKey]) ?>" class="topic-link <?= $topic === $topicKey ? 'topic-link--active' : '' ?>">
                                <?= $topicData['icon'] ?> <?= htmlspecialchars($topicData['title']) ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </aside>
            
            <!-- Main Content -->
            <div class="education-main">
                <?php if ($currentTopic): ?>
                <div class="education-article">
                    <div class="article-header">
                        <span class="article-icon"><?= $currentTopic['icon'] ?></span>
                        <h2><?= htmlspecialchars($currentTopic['title']) ?></h2>
                    </div>
                    <p class="article-intro"><?= htmlspecialchars($currentTopic['content']['intro']) ?></p>
                    
                    <?php foreach ($currentTopic['content']['sections'] as $section): ?>
                    <div class="article-section">
                        <h3><?= htmlspecialchars($section['heading']) ?></h3>
                        <p><?= htmlspecialchars($section['body']) ?></p>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="article-cta">
                        <h3>Ready to Compare Companies?</h3>
                        <p>Use our intelligence platform to find the best car hire company for your needs.</p>
                        <div class="article-cta-buttons">
                            <a href="<?= url('directory') ?>" class="btn btn--primary">Browse Directory</a>
                            <a href="<?= url('compare') ?>" class="btn btn--outline">Compare Companies</a>
                        </div>
                    </div>
                </div>
                
                <?php else: ?>
                <!-- Topic Overview -->
                <div class="topics-overview">
                    <h2>Complete Car Hire Guide for South Africa</h2>
                    <p>Everything you need to know about renting a car in South Africa — from deposits and excess to cross-border travel and seasonal demand.</p>
                    
                    <div class="topics-grid">
                        <?php foreach ($topics as $topicKey => $topicData): ?>
                        <a href="<?= url('education', '', ['topic' => $topicKey]) ?>" class="topic-card">
                            <div class="topic-card__icon"><?= $topicData['icon'] ?></div>
                            <h3 class="topic-card__title"><?= htmlspecialchars($topicData['title']) ?></h3>
                            <p class="topic-card__intro"><?= htmlspecialchars(truncate($topicData['content']['intro'], 100)) ?></p>
                            <span class="topic-card__link">Read Guide →</span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
